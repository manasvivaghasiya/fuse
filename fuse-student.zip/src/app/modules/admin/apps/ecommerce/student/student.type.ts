export interface studentProduct
{
    _id:string;
    category:string;
    productName:string;
    description:string;
    price:string;
    clothSize:string;
    inStock:string;
  
}