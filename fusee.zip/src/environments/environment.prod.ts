export const environment = {
    production: true,
    apiProduct:'https://student-api.mycodelibraries.com/api'

};
